 
#' @export
sample.mc = function(fit, cov, y, X, Z, nMC, trace = 0, family = "binomial", group, d, nZ, okindex ){
  # Things to address:
  ## Will need to make sure family "if else" statements are consistent 
  
  f = get(family, mode = "function", envir = parent.frame())
  
  # find tau for rejection sampler (Booth 1999) by first maximizing u
  if(length(okindex) > 0){
    fitu = glm(y ~ Z[,okindex]-1, offset = (X %*% fit$coef[1:ncol(X)]), family = f)
    uhat = fitu$coef
    uhat[is.na(uhat)] = 0
    eta = X %*% fit$coef[1:ncol(X)] + Z[,okindex] %*% uhat
  }else{
    uhat  = rep(0, ncol(Z))
    eta = X %*% fit$coef[1:ncol(X)] 
  }
  
  if(trace == 1) print(uhat)
  # calculate tau
  
  if(family == "binomial"){
    tau = dbinom(y, size = 1, prob = exp(eta)/(1+exp(eta)), log = T)
  }else if(family == "poisson"){
    tau = dpois(y, lambda = exp(eta), log = T)
  }else{
    print(family)
    stop("family not specified properly")
  }
  
  if(any(tau == 0)) tau = tau - 10^-20
  # matrix to hold accepted samples
  u0 = matrix(0 , nMC, ncol(Z))
  
  # fitted
  fitted = X %*% as.matrix(fit$coef[1:ncol(X)])
  #generate samples for each i
  for(i in 1:d){
    
    # find tau for rejection sampler (Booth 1999) by first maximizing u
    #Z2  = Z[i,] %*% matrix(1, nrow = ncol(Z), ncol = 1) 
    #fitu = glm(y[i] ~ Z2-1, offset = X[i,] %*% fit$coef, family = "poisson")
    #uhat = fitu$coef
    
    # calculate tau
    #eta = X[i,] %*% fit$coef + Z2 %*% uhat
    #tau = dpois(y[i], lambda = exp(eta))
    
    naccept = index = 0
    alreadyok = rep(F, nMC)
    while(naccept < nMC){
      # generate e
      #e = matrix(rmvnorm(n = nMC, mean  = rep(0, ncol(cov)), sigma = cov), ncol = ncol(cov))
      #e = matrix(rmvnorm(n = 1, mean  = rep(0, ncol(Z)), sigma = diag(rep(cov,ncol(Z)))), ncol = ncol(Z))
      select = group == i
      #e = rnorm(n = ceiling((index+1)/(naccept+1))*10, mean  = 0, sd = sqrt(cov))
      e = matrix(rmvnorm(n = ceiling((index+1)/(naccept+1))*10, mean  = rep(0, ncol(cov)), sigma = cov), ncol = ncol(cov))
      
      # vector of MC candidates, may need to revert to initial approach when have more complicated Z
      #etae = matrix(fitted[select], nrow = sum(select), ncol = length(e) ) +  ( matrix(e, nrow = sum(select), ncol = length(e), byrow = T))#sapply(e, FUN = function(ei) return(X[select,] %*% fit$coef + rowSums(Z[select,] * ei)))
      etae = matrix(fitted[select], nrow = sum(select), ncol = nrow(e)) +  Z[select,seq(i, ncol(Z), by = d)]%*%t(e)#sapply(e, FUN = function(ei) return(X[select,] %*% fit$coef + rowSums(Z[select,] * ei)))
      
      
      # generate w
      w = runif(nrow(e))
      
      
      #if(w < dpois(y[i], lambda =  exp(etae))/tau){
      # pick the first e that satisfies the condition
      
      if(family == "binomial"){
        ok = log(w) < apply(etae, 2, FUN = function(etaei) sum(dbinom(y[select], size = 1, prob = exp(etaei)/(1+exp(etaei)), log = T)) - sum(tau[select]))
      }else if(family == "poisson"){
        ok = log(w) < apply(etae, 2, FUN = function(etaei) sum(dpois(y[select], lambda =  exp(etaei), log = T)) - sum(tau[select]))
      }else{
        print(family)
        stop("family not specified properly")
      }
      
      
      if(any(ok)){
        u0[naccept+1,seq(i, ncol(Z), by = d)] = e[which(ok)[1],]
        #alreadyok = rowSums(u0) != 0
        naccept = naccept + 1#sum(alreadyok)
        if(trace == 1) cat(sprintf("mc i:%d naccept: %d index: %d\n",i, naccept, index))
      }
      index = index + 1
    }
    # for each i, rbind the nMC samples together to make n*nMC x d matrix (d = dim(Z))
  }
  return(u0)
}

#' Calculate Monte Carlo draws
#' 
#' \code{sample.mc2} calculates the Monte Carlo draws by either Rejection sampling or 
#' Metropolis-within-Gibbs sampling needed for Monte Carlo Expectation Conditional Minimization (MCECM)
#'
#' @inheritParams fit_dat
#' @param fit a grpreg fit object (set \code{\link[grpreg]{grpreg}})
#' @param cov the random effects covariance matrix estimated from the last M step of the EM algorithm
#' @param y a numeric vector of the response variable
#' @param X a model matrix of the fixed effects covariates
#' @param Z a sparse model matrix of the random effects
#' @param group a factor vector of the grouping variable, converted to a factor of 
#' consecutive numeric integers
#' @param d integer, the number of groups present (number factors of the group vector)
#' @param okindex ?
#' @param uold a matrix of the Monte Carlo draws from the last E step of the EM algorithm
#' 
#' @return a list made of the following components:
#' \item{u0}{a matrix of the Monte Carlo draws (from Rejection sampling if gibbs = F, or 
#' from Metropolis-within-Gibbs sampling if gibbs = T). Number rows = nMC, number columns = 
#' (number random effects)x(number groups). Organization of columns: first by random effect variable,
#' then by group within variable (i.e. Var1:Grp1 Var1:Grp2 ... Var1:GrpK Var2:Grp1 ... Varq:GrpK)}
#' \item{switch}{logical, did the sampling scheme switch from Rejection sampling to 
#' Metropolis-within-Gibbs sampling?}
#'
#' @export
sample.mc2 = function(fit, cov, y, X, Z, nMC, trace = 0, family = family, group, d, nZ, okindex,
                      gibbs = F , uold){
  
  f = get(family, mode = "function", envir = parent.frame())
  
  # find tau for rejection sampler (Booth 1999) by first maximizing u
  if(length(okindex) > 0 & gibbs == F){
    fitu = glm(y ~ Z[,okindex]-1, offset = (X %*% fit$coef[1:ncol(X)]), family = f)
    uhat = fitu$coef
    uhat[is.na(uhat)] = 0
    eta = X %*% fit$coef[1:ncol(X)] + Z[,okindex] %*% uhat
  }else{
    uhat  = rep(0, ncol(Z))
    eta = X %*% fit$coef[1:ncol(X)] 
  }
  
  #if(trace == 1) print(uhat)
  # calculate tau
  
  if(family == "binomial" & gibbs == F){
    tau = dbinom(y, size = 1, prob = exp(eta)/(1+exp(eta)), log = T)
  }else if(family == "poisson" & gibbs == F){
    tau = dpois(y, lambda = exp(eta), log = T)
  }
  
  #if(any(tau == 0)) tau = tau - 10^-20
  # matrix to hold accepted samples
  u0 = matrix(rnorm(nMC*ncol(Z)) , nMC, ncol(Z))
  #u0 = Matrix(0 , nMC, ncol(Z), sparse = T)
  
  # fitted
  fitted_mat = as.matrix(X %*% fit$coef[1:ncol(X)])
  #generate samples for each i
  
  error_out = F
  
  if(gibbs == F){ # Rejection sampling
    
    for(i in 1:d){
      
      if(error_out){
        next
      }
      
      select = group == i
      index = seq(i, ncol(Z), by = d)
      ## new code to limit to non-zero z, skipping elements of q where diag(sigma) are 0
      index = index[which(diag(cov) != 0)]
      if(length(index) == 0) next
      
      draws = sample_mc_inner(matrix(fitted_mat[select], ncol = 1, nrow = sum(select)), 
                              matrix(Z[select,index],ncol = length(index), nrow = sum(select)), 
                              y[select], tau[select], nMC, trace)
      
      # If sample_mc_inner did not error out (i.e. have too small an acceptance rate), then continue
      if(nrow(draws) == nMC){
        u0[,index] = draws
      }else{ # If too small an acceptance rate
        cat("switched to gibbs sampling (single round) \n")
        error_out = T
        next
      }
      
    }
    
    # If at any point the sample_mc_inner errored out due to too low of acceptance rate, then 
    # switch to gibbs sampling (redo entire u matrix as gibbs sampling)
    if(error_out){
      for(i in 1:d){
        select = group == i
        index = seq(i, ncol(Z), by = d)
        ## new code to limit to non-zero z, skipping elements of q where diag(sigma) are 0
        index = index[which(diag(cov) != 0)]
        if(length(index) == 0) next
        
        u0[,index] = sample_mc_inner_gibbs(matrix(fitted_mat[select], ncol = 1, nrow = sum(select)), 
                                           matrix(Z[select,index],ncol = length(index), nrow = sum(select)),  
                                           y[select], uhat[index], nMC, as.numeric((uold[nrow(uold),index, drop = FALSE])), trace) 
      }
    }
    
  }else{ # Gibbs sampling
    for(i in 1:d){
      select = group == i
      index = seq(i, ncol(Z), by = d)
      ## new code to limit to non-zero z, skipping elements of q where diag(sigma) are 0
      index = index[which(diag(cov) != 0)]
      if(length(index) == 0) next
      
      u0[,index] = sample_mc_inner_gibbs(matrix(fitted_mat[select], ncol = 1, nrow = sum(select)), 
                                         matrix(Z[select,index],ncol = length(index), nrow = sum(select)),  
                                         y[select], uhat[index], nMC, as.numeric((uold[nrow(uold),index, drop = FALSE])), trace)
    }
  }
  # for each i, rbind the nMC samples together to make n*nMC x d matrix (d = dim(Z))
  
  if(gibbs == F){
    cat("switch: ", error_out, "\n")
  }
  
  # return(u0)
  # switch: variable indicating if switched from rejection sampling to gibbs sampling
  return(list(u0 = u0, switch = error_out))
}

