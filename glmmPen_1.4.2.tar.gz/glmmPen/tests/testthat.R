library(testthat)
library(glmmPen)

test_check("glmmPen")
