## to do - for cases where grps = number of vectors, just do one large SVD
## removed creation of XX, copy of X.  Saving to original X to save memory
## switched svd to fast.svd
## added gc() step to clear memory after each svd round

orthogonalize <- function(X, group) {
print("orthog")
  library(corpcor)
  n <- nrow(X)
  J <- max(group)
print(group)
  T <- vector("list", J)
  #XX <- matrix(0, nrow=nrow(X), ncol=ncol(X))
gc()
  #XX[,which(group==0)] <- X[,which(group==0)]
  for (j in seq_along(numeric(J))) {
    ind <- which(group==j)
    if (length(ind)==0) next
    SVD <- fast.svd(X[, ind, drop=FALSE])
    #SVD <- svd(X[, ind, drop=FALSE], nu = 0)
    r <- which(SVD$d > 1e-10)
    T[[j]] <- sweep(SVD$v[,r,drop=FALSE], 2, sqrt(n)/SVD$d[r], "*")
    #XX[,ind[r]] <- X[,ind]%*%T[[j]]
#    print(dim(X[,ind[r]]))
#print(dim(T[[j]]))
#print(dim(X[,ind]%*%T[[j]]))


    X[,ind[r]] <- X[,ind]%*%T[[j]]
    if(length(r) < length(ind)) X[,ind[-r]] = 0 
gc()
  }

  #nz <- !apply(XX==0,2,all)
  #XX <- XX[, nz, drop=FALSE]
  #attr(XX, "T") <- T
  #attr(XX, "group") <- group[nz]
  #XX
  nz <- !apply(X==0,2,all)
  X <- X[, nz, drop=FALSE]
  attr(X, "T") <- T
  attr(X, "group") <- group[nz]
  X
}
unorthogonalize <- function(b, XX, group) {
print("unorth")
  ind <- !sapply(attr(XX, "T"), is.null)
  T <- bdiag(attr(XX, "T")[ind])
  print(dim(T))
#print(length(b))
#print(length(group))
  ind0 <- c(1, 1+which(group==0))
  rbind(b[ind0,,drop=FALSE], as.matrix(T %*% b[-ind0,,drop=FALSE]))
}
